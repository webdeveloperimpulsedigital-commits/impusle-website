import React, { useState } from "react";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import { Input } from "../../../../components/ui/input";
import { Label } from "../../../../components/ui/label";
import { Textarea } from "../../../../components/ui/textarea";

export const ApplicationFormSection = (): JSX.Element => {
  const [selectedPosition, setSelectedPosition] = useState("");
  const [fileName, setFileName] = useState("");

  const positions = [
    "Digital Marketing Manager",
    "Content Writer", 
    "SEO Specialist",
    "Graphic Designer",
    "Other Position"
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here
    console.log("Application submitted");
  };

  return (
    <section id="application-form" className="w-full bg-[#f8f9fa] py-16 lg:py-24" data-section="application-form">
      <div className="max-w-[800px] mx-auto px-4 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="[font-family:'DM_Sans',Helvetica] font-bold text-[#030019] text-3xl md:text-4xl lg:text-5xl mb-6">
            Apply Now
          </h2>
          <p className="[font-family:'DM_Sans',Helvetica] font-normal text-[#666] text-base leading-relaxed">
            Ready to join our team? Fill out the form below and attach your resume. We'll get back to you within 48 hours.
          </p>
        </div>

        {/* Application Form */}
        <Card className="bg-white rounded-2xl border-0 shadow-lg">
          <CardContent className="p-8 lg:p-12">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Position Selection */}
              <div className="space-y-3">
                <Label className="[font-family:'DM_Sans',Helvetica] font-medium text-[#030019] text-base">
                  Position Applying For *
                </Label>
                <select
                  value={selectedPosition}
                  onChange={(e) => setSelectedPosition(e.target.value)}
                  required
                  className="w-full h-[50px] px-4 py-3 bg-[#f8f9fa] rounded-lg border border-gray-200 [font-family:'DM_Sans',Helvetica] font-normal text-[#030019] text-base focus:border-[#543d98] focus:outline-none transition-colors"
                >
                  <option value="">Select a position</option>
                  {positions.map((position) => (
                    <option key={position} value={position}>
                      {position}
                    </option>
                  ))}
                </select>
              </div>

              {/* Personal Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <Label htmlFor="firstName" className="[font-family:'DM_Sans',Helvetica] font-medium text-[#030019] text-base">
                    First Name *
                  </Label>
                  <Input
                    id="firstName"
                    type="text"
                    required
                    placeholder="Enter your first name"
                    className="h-[50px] px-4 py-3 bg-[#f8f9fa] rounded-lg border border-gray-200 [font-family:'DM_Sans',Helvetica] font-normal text-[#030019] text-base focus:border-[#543d98] focus:outline-none transition-colors"
                  />
                </div>

                <div className="space-y-3">
                  <Label htmlFor="lastName" className="[font-family:'DM_Sans',Helvetica] font-medium text-[#030019] text-base">
                    Last Name *
                  </Label>
                  <Input
                    id="lastName"
                    type="text"
                    required
                    placeholder="Enter your last name"
                    className="h-[50px] px-4 py-3 bg-[#f8f9fa] rounded-lg border border-gray-200 [font-family:'DM_Sans',Helvetica] font-normal text-[#030019] text-base focus:border-[#543d98] focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Contact Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <Label htmlFor="email" className="[font-family:'DM_Sans',Helvetica] font-medium text-[#030019] text-base">
                    Email Address *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    required
                    placeholder="Enter your email address"
                    className="h-[50px] px-4 py-3 bg-[#f8f9fa] rounded-lg border border-gray-200 [font-family:'DM_Sans',Helvetica] font-normal text-[#030019] text-base focus:border-[#543d98] focus:outline-none transition-colors"
                  />
                </div>

                <div className="space-y-3">
                  <Label htmlFor="phone" className="[font-family:'DM_Sans',Helvetica] font-medium text-[#030019] text-base">
                    Phone Number *
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    required
                    placeholder="Enter your phone number"
                    className="h-[50px] px-4 py-3 bg-[#f8f9fa] rounded-lg border border-gray-200 [font-family:'DM_Sans',Helvetica] font-normal text-[#030019] text-base focus:border-[#543d98] focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Experience */}
              <div className="space-y-3">
                <Label htmlFor="experience" className="[font-family:'DM_Sans',Helvetica] font-medium text-[#030019] text-base">
                  Years of Experience *
                </Label>
                <select
                  id="experience"
                  required
                  className="w-full h-[50px] px-4 py-3 bg-[#f8f9fa] rounded-lg border border-gray-200 [font-family:'DM_Sans',Helvetica] font-normal text-[#030019] text-base focus:border-[#543d98] focus:outline-none transition-colors"
                >
                  <option value="">Select experience level</option>
                  <option value="0-1">0-1 years (Fresher)</option>
                  <option value="1-2">1-2 years</option>
                  <option value="2-3">2-3 years</option>
                  <option value="3-5">3-5 years</option>
                  <option value="5+">5+ years</option>
                </select>
              </div>

              {/* Resume Upload */}
              <div className="space-y-3">
                <Label htmlFor="resume" className="[font-family:'DM_Sans',Helvetica] font-medium text-[#030019] text-base">
                  Upload Resume *
                </Label>
                <div className="relative">
                  <input
                    id="resume"
                    type="file"
                    accept=".pdf,.doc,.docx"
                    required
                    onChange={handleFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <div className="flex items-center justify-between h-[50px] px-4 py-3 bg-[#f8f9fa] rounded-lg border border-gray-200 border-dashed hover:border-[#543d98] transition-colors">
                    <span className="[font-family:'DM_Sans',Helvetica] font-normal text-[#666] text-base">
                      {fileName || "Choose file (PDF, DOC, DOCX)"}
                    </span>
                    <div className="flex items-center gap-2">
                      <svg className="w-5 h-5 text-[#543d98]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                      </svg>
                      <span className="[font-family:'DM_Sans',Helvetica] font-medium text-[#543d98] text-sm">
                        Upload
                      </span>
                    </div>
                  </div>
                </div>
                <p className="text-xs text-[#666] mt-1">
                  Maximum file size: 5MB. Accepted formats: PDF, DOC, DOCX
                </p>
              </div>

              {/* Cover Letter */}
              <div className="space-y-3">
                <Label htmlFor="coverLetter" className="[font-family:'DM_Sans',Helvetica] font-medium text-[#030019] text-base">
                  Cover Letter / Message
                </Label>
                <Textarea
                  id="coverLetter"
                  placeholder="Tell us why you're interested in this position and what makes you a great fit for our team..."
                  rows={6}
                  className="px-4 py-3 bg-[#f8f9fa] rounded-lg border border-gray-200 [font-family:'DM_Sans',Helvetica] font-normal text-[#030019] text-base focus:border-[#543d98] focus:outline-none transition-colors resize-none"
                />
              </div>

              {/* Portfolio/LinkedIn (Optional) */}
              <div className="space-y-3">
                <Label htmlFor="portfolio" className="[font-family:'DM_Sans',Helvetica] font-medium text-[#030019] text-base">
                  Portfolio/LinkedIn URL (Optional)
                </Label>
                <Input
                  id="portfolio"
                  type="url"
                  placeholder="https://your-portfolio.com or LinkedIn profile"
                  className="h-[50px] px-4 py-3 bg-[#f8f9fa] rounded-lg border border-gray-200 [font-family:'DM_Sans',Helvetica] font-normal text-[#030019] text-base focus:border-[#543d98] focus:outline-none transition-colors"
                />
              </div>

              {/* Submit Button */}
              <div className="pt-6">
                <Button 
                  type="submit"
                  className="w-full h-[60px] bg-[#543d98] hover:bg-[#543d98]/90 text-white rounded-xl font-bold text-lg transition-colors duration-300 flex items-center justify-center gap-3"
                >
                  Submit Application
                  <img className="w-5 h-5" alt="Arrow" src="/button-icon.svg" />
                </Button>
              </div>

              {/* Privacy Notice */}
              <div className="pt-4 text-center">
                <p className="text-xs text-[#666] leading-relaxed">
                  By submitting this application, you agree to our privacy policy. We will only use your information for recruitment purposes.
                </p>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Contact Info */}
        <div className="mt-12 text-center">
          <p className="[font-family:'DM_Sans',Helvetica] font-normal text-[#666] text-base mb-4">
            Have questions about any position? Contact our HR team:
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a 
              href="mailto:careers@theimpulsedigital.com"
              className="flex items-center gap-2 text-[#543d98] hover:text-[#543d98]/80 transition-colors"
            >
              <img src="/sms.png" alt="Email" className="w-4 h-4" />
              <span className="[font-family:'DM_Sans',Helvetica] font-medium">
                careers@theimpulsedigital.com
              </span>
            </a>
            <span className="hidden sm:block text-[#666]">|</span>
            <a 
              href="tel:+919769285224"
              className="flex items-center gap-2 text-[#543d98] hover:text-[#543d98]/80 transition-colors"
            >
              <img src="/call.png" alt="Phone" className="w-4 h-4" />
              <span className="[font-family:'DM_Sans',Helvetica] font-medium">
                +91-9769285224
              </span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};