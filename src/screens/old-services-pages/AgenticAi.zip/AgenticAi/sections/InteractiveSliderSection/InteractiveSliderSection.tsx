import React, { useState, useEffect } from "react";
import { Button } from "../../../../components/ui/button";

interface SlideData {
  id: number;
  image: string;
  alt: string;
  smallHeading: string;
  mainHeading: string;
  paragraph: string;
  clientName: string;
  tags: string[];
}

export const InteractiveSliderSection = (): JSX.Element => {
  const [activeSlide, setActiveSlide] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  // Check for reduced motion preference
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mediaQuery.matches);
    
    const handleChange = (e: MediaQueryListEvent) => {
      setPrefersReducedMotion(e.matches);
    };
    
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        goToPrevious();
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        goToNext();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeSlide]);

  const slides: SlideData[] = [
    {
      id: 1,
      image: "https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Person working on SEO strategy with digital analytics and laptop",
      smallHeading: "Providing SEO",
      mainHeading: "Solutions to Solve Your Problems",
      paragraph: "One problem can have multiple solutions. But which one will help you get the results? Wait. Why are you stressing over it when we can take care of it? It's time we turn your search visibility into your biggest strength.",
      clientName: "Mastercard Inc.",
      tags: ["PRODUCT DESIGN", "BRANDING", "CREATIVE"]
    },
    {
      id: 2,
      image: "https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Hand holding smartphone with search interface and digital elements",
      smallHeading: "Content Strategy",
      mainHeading: "Words That Drive Action",
      paragraph: "Every piece of content we create is designed with purpose. From blog posts that educate to landing pages that convert, we craft messaging that resonates with your audience and drives meaningful engagement.",
      clientName: "Amazon India",
      tags: ["CONTENT STRATEGY", "COPYWRITING", "DIGITAL"]
    },
    {
      id: 3,
      image: "https://images.pexels.com/photos/574071/pexels-photo-574071.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Creative workspace with laptop, notebooks, and design materials",
      smallHeading: "Brand Development",
      mainHeading: "Building Memorable Experiences",
      paragraph: "We don't just create brands; we build experiences that stick. Through strategic positioning and creative execution, we help your brand stand out in a crowded marketplace and connect with your ideal customers.",
      clientName: "OLA Mobility",
      tags: ["BRAND STRATEGY", "DESIGN", "EXPERIENCE"]
    }
  ];

  // NEW: freeze left-side content to the first slide (keep code intact elsewhere)
  const fixedSlide = slides[0];

  const handleSlideChange = (newIndex: number) => {
    if (isTransitioning || newIndex === activeSlide) return;
    
    if (prefersReducedMotion) {
      setActiveSlide(newIndex);
      return;
    }
    
    setIsTransitioning(true);
    setActiveSlide(newIndex);
    
    // Reset transition state after animation completes
    setTimeout(() => {
      setIsTransitioning(false);
    }, 450);
  };

  const goToPrevious = () => {
    const newIndex = activeSlide === 0 ? slides.length - 1 : activeSlide - 1;
    handleSlideChange(newIndex);
  };

  const goToNext = () => {
    const newIndex = activeSlide === slides.length - 1 ? 0 : activeSlide + 1;
    handleSlideChange(newIndex);
  };

  const currentSlide = slides[activeSlide];

  // Get card positions for deck effect
  const getCardStyle = (index: number) => {
    const position = (index - activeSlide + slides.length) % slides.length;
    
    if (prefersReducedMotion) {
      return {
        display: position === 0 ? 'block' : 'none',
        willChange: 'auto'
      } as React.CSSProperties;
    }

    const baseStyle: React.CSSProperties = {
      willChange: 'transform',
      transition: 'transform 400ms cubic-bezier(0.22, 1, 0.36, 1), opacity 400ms cubic-bezier(0.22, 1, 0.36, 1), filter 400ms cubic-bezier(0.22, 1, 0.36, 1)'
    };

    switch (position) {
      case 0: // Active card
        return {
          ...baseStyle,
          transform: 'translateX(0) scale(1)',
          opacity: 1,
          filter: 'blur(0px)',
          zIndex: 30
        };
      case 1: // Next card
        return {
          ...baseStyle,
          transform: 'translateX(24px) scale(0.97)',
          opacity: 0.8,
          filter: 'blur(1px)',
          zIndex: 20
        };
      case 2: // Third card
        return {
          ...baseStyle,
          transform: 'translateX(48px) scale(0.94)',
          opacity: 0.6,
          filter: 'blur(2px)',
          zIndex: 10
        };
      default: // Hidden cards
        return {
          ...baseStyle,
          transform: 'translateX(72px) scale(0.97)',
          opacity: 0,
          filter: 'blur(3px)',
          zIndex: 0
        };
    }
  };

  return (
    <section className="w-full bg-white py-16 lg:py-20" data-section="interactive-slider">
      <div className="max-w-[1280px] mx-auto px-4 lg:px-8">
        {/* Desktop Layout */}
        <div className="hidden md:grid md:grid-cols-5 gap-8 lg:gap-12 items-center">
          {/* Left Side - Content (60% width) */}
          <div className="md:col-span-2 space-y-6">
            <div 
              className={`space-y-2 ${
                prefersReducedMotion 
                  ? '' 
                  : `transition-all duration-400 ease-[cubic-bezier(0.22,1,0.36,1)] ${
                      'opacity-100 translate-y-0'
                    }`
              }`}
              aria-live="polite"
            >
              {/* LEFT CONTENT FIXED */}
              <p className="[font-family:'DM_Sans',Helvetica] font-normal text-[#030019] text-lg">
                {fixedSlide.smallHeading}
              </p>
              <h2 className="[font-family:'DM_Sans',Helvetica] font-bold text-[#543d98] text-3xl lg:text-4xl xl:text-5xl leading-tight">
                {fixedSlide.mainHeading}
              </h2>
            </div>

            <div 
              className={`${
                prefersReducedMotion 
                  ? '' 
                  : `transition-all duration-400 ease-[cubic-bezier(0.22,1,0.36,1)] delay-75 ${
                      'opacity-100 translate-y-0'
                    }`
              }`}
            >
              {/* LEFT CONTENT FIXED */}
              <p className="[font-family:'DM_Sans',Helvetica] font-normal text-[#030019] text-base leading-relaxed mb-8">
                {fixedSlide.paragraph}
              </p>
            </div>

            {/* Navigation Buttons */}
            <div className="flex items-center gap-4 mb-8">
               
              
               <button
                onClick={goToPrevious}
                disabled={isTransitioning}
                className="w-12 h-12 rounded-full border-2 border-[#543d98] bg-white hover:border-[#543d98] hover:bg-[#543d98] hover:text-white transition-all duration-300 flex items-center justify-center group disabled:opacity-50 disabled:cursor-not-allowed"
                aria-label="Previous slide">
                 <img 
                    src="/impulse-website/left-arrow.png" 
                    alt="Previous" 
                    className="w-5 h-5 object-contain group-hover:filter group-hover:invert transition-all"
                  />
              </button>
              <button
                onClick={goToNext}
                disabled={isTransitioning}
                className="w-12 h-12 rounded-full border-2 border-[#EAEAEA] bg-[#543d98] hover:border-[#543d98] hover:bg-[#543d98] hover:text-white transition-all duration-300 flex items-center justify-center group disabled:opacity-50 disabled:cursor-not-allowed"
                aria-label="Next slide">
                <img src="/impulse-website/right-arrow.png" 
                    alt="Previous" 
                    className="w-5 h-5 object-contain group-hover:filter group-hover:invert transition-all"
                  />
              </button>
            </div>
          </div>

          {/* Right Side - Image Deck and Client Info (60% width) */}
          <div className="md:col-span-3 space-y-6">
            {/* Image Deck */}
            <div className="relative h-[400px] lg:h-[500px]">
              {slides.map((slide, index) => (
                <div
                  key={slide.id}
                  className="absolute inset-0 rounded-2xl overflow-hidden shadow-lg"
                  style={getCardStyle(index)}>
                  <img
                    src={slide.image}
                    alt={slide.alt}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>
              ))}
            </div>

            {/* Client Info (still changes with slide) */}
            <div 
              className={`${
                prefersReducedMotion 
                  ? '' 
                  : `transition-all duration-400 ease-[cubic-bezier(0.22,1,0.36,1)] delay-150 ${
                      'opacity-100 translate-y-0'
                    }`
              }`}
            >
              <h3 className="[font-family:'DM_Sans',Helvetica] font-bold text-[#030019] text-xl mb-3">
                {currentSlide.clientName}
              </h3>
              
              <div className="flex flex-wrap gap-2">
                {currentSlide.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="px-4 py-2 bg-transparent border border-[#EAEAEA] rounded-full text-xs font-medium text-[#666] uppercase tracking-wide"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Layout */}
        <div className="block md:hidden space-y-8">
          {/* Mobile Image Deck */}
          <div className="relative h-[300px]">
            {slides.map((slide, index) => (
              <div
                key={slide.id}
                className="absolute inset-0 rounded-2xl overflow-hidden shadow-lg"
                style={getCardStyle(index)}
              >
                <img
                  src={slide.image}
                  alt={slide.alt}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>
            ))}
          </div>

          {/* Mobile Content (LEFT CONTENT FIXED) */}
          <div className="space-y-6">
            <div 
              className={`space-y-2 ${
                prefersReducedMotion 
                  ? '' 
                  : `transition-all duration-400 ease-[cubic-bezier(0.22,1,0.36,1)] ${
                      'opacity-100 translate-y-0'
                    }`
              }`}
              aria-live="polite"
            >
              <p className="[font-family:'DM_Sans',Helvetica] font-normal text-[#030019] text-lg">
                {fixedSlide.smallHeading}
              </p>
              <h2 className="[font-family:'DM_Sans',Helvetica] font-bold text-[#543d98] text-2xl lg:text-3xl leading-tight">
                {fixedSlide.mainHeading}
              </h2>
            </div>

            <div 
              className={`${
                prefersReducedMotion 
                  ? '' 
                  : `transition-all duration-400 ease-[cubic-bezier(0.22,1,0.36,1)] delay-75 ${
                      'opacity-100 translate-y-0'
                    }`
              }`}
            >
              <p className="[font-family:'DM_Sans',Helvetica] font-normal text-[#030019] text-base leading-relaxed mb-6">
                {fixedSlide.paragraph}
              </p>
            </div>

            {/* Mobile Navigation Buttons */}
            <div className="flex items-center gap-4 mb-6">
              <button
                onClick={goToPrevious}
                disabled={isTransitioning}
                className="w-10 h-10 rounded-full border-2 border-[#EAEAEA] bg-white hover:border-[#543d98] hover:bg-[#543d98] hover:text-white transition-all duration-300 flex items-center justify-center group disabled:opacity-50 disabled:cursor-not-allowed"
                aria-label="Previous slide"
              >
                <svg className="w-4 h-4 text-[#666] group-hover:text-white transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              
              <button
                onClick={goToNext}
                disabled={isTransitioning}
                className="w-10 h-10 rounded-full border-2 border-[#EAEAEA] bg-white hover:border-[#543d98] hover:bg-[#543d98] hover:text-white transition-all duration-300 flex items-center justify-center group disabled:opacity-50 disabled:cursor-not-allowed"
                aria-label="Next slide"
              >
                <svg className="w-4 h-4 text-[#666] group-hover:text-white transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>

            {/* Mobile Client Info (still changes with slide) */}
            <div 
              className={`${
                prefersReducedMotion 
                  ? '' 
                  : `transition-all duration-400 ease-[cubic-bezier(0.22,1,0.36,1)] delay-150 ${
                      'opacity-100 translate-y-0'
                    }`
              }`}
            >
              <h3 className="[font-family:'DM_Sans',Helvetica] font-bold text-[#030019] text-lg mb-3">
                {currentSlide.clientName}
              </h3>
              
              <div className="flex flex-wrap gap-2">
                {currentSlide.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="px-3 py-1.5 bg-transparent border border-[#EAEAEA] rounded-full text-xs font-medium text-[#666] uppercase tracking-wide"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Slide Indicators */}
        <div className="flex justify-center gap-2 mt-8">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => handleSlideChange(index)}
              disabled={isTransitioning}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                index === activeSlide 
                  ? 'bg-[#543d98] w-6' 
                  : 'bg-[#EAEAEA] hover:bg-[#543d98]/50'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>

      {/* Custom Styles */}
      <style>{`
        @media (prefers-reduced-motion: reduce) {
          * {
            transition-duration: 0.1s !important;
            animation-duration: 0.1s !important;
          }
        }
      `}</style>
    </section>
  );
};
