export const BrandVisionSection = (): JSX.Element => {
  const overlayText ="As brands, there's so much you want to communicate to your audience what do you stand for";
  const steps = [
    {
      title: "Discovery and Research",
      description:
        "We begin by understanding your goals, audience, and tone, supported by keyword and market research to build performance-driven content",
    },
    {
      title: "Strategy and Structure",
      description:
        "We define messaging, map it to funnel stages, and create a clear structure and tone aligned with your objectives",
    },
    {
      title: "Creation and Optimization",
      description:
        "Our writers craft original, SEO optimized content that blends brand context, clarity, and engagement for maximum visibility",
    },
    {
      title: "Review and Performance",
      description:
        "Every piece goes through editorial checks and client review, followed by tracking visibility, engagement, and conversions to improve future content.",
    },
  ];

  const loopedSteps = [...steps, ...steps];

  const mobileRows = steps.reduce<string[][]>((rows, _, i) => {
    if (i % 2 === 0) rows.push(steps.slice(i, i + 2));
    return rows as any;
  }, [] as any);

  return (
    <section
      className="w-full bg-white lg:py-5 sm:py-8" id="sec-border"
      data-section="brand-vision"
    >
      <div className="max-w-[1280px] mx-auto px-2 lg:px-5 sm:py-10">
        {/* Title */}
        <div className="mb-6 lg:mb-8 pt-10">
            <h2 className="[font-family:'DM_Sans',Helvetica] text-[#030019] font-medium lg:text-[34px] sm:text-[16px] ">

            Turn Brand Vision


          </h2>
          <h2 className="[font-family:'DM_Sans',Helvetica] font-bold text-[#543d98] lg:text-[52px] sm:text-[20px] leading-tight ">
            Into Words That Convert

          </h2>
        </div>

        {/* Main row: smaller image + stats; bubble straddles center */}
        <div className="relative grid grid-cols-1 lg:grid-cols-12 gap-4 lg:gap-12 items-start mb-6">
          {/* IMAGE (smaller width) */}
          <div className="lg:col-span-5 lg:w-[600px]">
            <div className="relative rounded-2xl overflow-hidden shadow-lg ">
              <img
                src="/impulse-website/content-wrriting-service-about-us.jpg"
                alt="SEO workspace"
                className="w-full sm:h-[400px] lg:h-[700px] object-cover"
              />
            </div>
          </div>
          {/* ✅ Mobile version — moves below image */}
            <div className="block lg:hidden -mt-8 px-2 mt-0" style={{ marginTop: '-18%', zIndex: '999'}}> 
              <div className="bg-white rounded-2xl p-4 shadow-[0_10px_30px_rgba(0,0,0,0.08)]">
                <p className="[font-family:'DM_Sans',Helvetica] text-[#030019] font-medium text-[20px] leading-[20px] text-left p-7">
                  {overlayText}
                </p>
              </div>
            </div>
          {/* STATS area */}
          <div className="lg:mt-[35%] lg:ml-[25%] mt-0 ml-[3%] mr-[3%] lg:col-span-7">

            {/* Use relative box to absolutely place left/right/left stats */}
            <div className="relative h-[500px] lg:h-[400px] lg:w-[520px] sm:h-[500px]">
              {/* TOP-LEFT (50%) */}
              <div className="absolute top-6 left-0 text-center">
                <h2 className="[font-family:'Space Grotesk', sans-serif] text-[#543d98] text-4xl lg:text-6xl font-black leading-none mb-2">
                  95%
                  <p className="[font-family:'DM_Sans',Helvetica] text-[#030019] text-[16px] leading-relaxed max-w-[250px] font-[400] text-[16px]">
                  clients achieved top 1st page search rankings for their target keywords


                </p>
                </h2>
                
              </div>

              {/* MIDDLE-RIGHT (50%) */}
              <div className="absolute top-1/2 -translate-y-1/2 right-0 text-center mb-8">
                <h2 className="[font-family:'DM_Sans',Helvetica] text-[#543d98] text-4xl lg:text-6xl font-black leading-none mb-2 ">
                  80%
                  <p className="[font-family:'DM_Sans',Helvetica] text-[#030019] text-[16px] leading-relaxed max-w-[250px] font-[400] text-[16px]">
                  of our clients see improved results within the first 3 months.
                </p>
                </h2>
                
              </div>

              {/* BOTTOM-LEFT (23%) */}
              <div className="absolute bottom-6 left-0 text-center">
                <h2 className="[font-family:'DM_Sans',Helvetica] text-[#543d98] text-4xl lg:text-6xl font-black leading-none mb-2">
                  3.5X
                  <p className="[font-family:'DM_Sans',Helvetica] text-[#030019] text-[16px] leading-relaxed max-w-[250px] font-[400] text-[16px]">
                  business growth for our clients after leveraging our expert SEO services.
                </p>
                </h2>
                
              </div>
            </div>
          </div>

          {/* CONTENT BUBBLE that sits HALF on image & HALF in right area */}
          {/* It’s anchored to the grid center using left-1/2 and -translate-x-1/2 */}
          {/* ✅ Desktop version — stays absolute and centered */}
            <div className="pointer-events-none absolute top-8 left-1/2 -translate-x-1/2 w-full max-w-[700px] px-4 hidden lg:block">
              <div className="pointer-events-auto bg-white rounded-2xl p-5 lg:p-6">
                <p className="[font-family:'DM_Sans',Helvetica] text-[#030019] text-[12px] lg:text-[34px] sm:leading-[20px] lg:leading-[42px] text-left">
                  {overlayText}
                </p>
              </div>
            </div>


            

        </div>

        {/* Body copy */}
        <div className="text-left mb-12">
          <p className="[font-family:'DM_Sans',Helvetica] font-normal text-[12px] lg:text-[24px] text-[#030019]">
            What do you have in store, where are you coming from, and why are you the best fit for your audience? Here’s the catch. Poorly written content can lead to lost leads, lower search engine rankings, and a diminishing brand image. A reliable content writing agency or content writing company transforms your brand’s vision into actionable words that attract, engage, and retain your audience. From blogs that position you as thought leaders to marketing email copy that makes your readers click the button, every piece is tailored for action.
          </p>
        </div>

       
      </div>

       {/* 4 service cards */}
        {/* ---------- DESKTOP AUTO SCROLL (RIGHT → LEFT) ---------- */}
        <div className="relative hidden md:block">
          <div className="absolute left-0 right-0 top-[35px] h-[2px] bg-[#EAEAEA] z-0" />
          <div className="overflow-hidden">
            <div className="steps-track flex gap-16 py-6 will-change-transform relative z-10">
              {loopedSteps.map((s, i) => (
                <div key={i} className="min-w-[260px] max-w-[300px] relative">
                  <div className="absolute top-[9px] left-0 w-2 h-2 rounded-full bg-[#6B04FD]" />
                  <div className="pt-10">
                    <h3 className="[font-family:'DM_Sans',Helvetica] font-bold text-[#030019] text-[20px] mb-1">
                      {s.title}
                    </h3>
                    <p className="[font-family:'DM_Sans',Helvetica] text-[#666] text-[18px] leading-relaxed">
                      {s.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ---------- MOBILE STATIC GRID ---------- */}
        <div className="block md:hidden space-y-10 px-4 mb-14">
          {mobileRows.map((pair, rowIdx) => (
            <div key={rowIdx} className="relative">
              <div className="absolute left-0 right-0 top-[13px] h-[2px] bg-[#EAEAEA]" />
              <div className="grid grid-cols-2 gap-x-8 gap-y-6">
                {pair.map((s, i) => (
                  <div key={i} className="relative">
                    <div className="absolute top-[9px] left-0 w-2 h-2 rounded-full bg-[#6B04FD]" />
                    <div className="pt-10">
                      <h3 className="[font-family:'DM_Sans',Helvetica] font-bold text-[#030019] text-[18px] leading-snug mb-1">
                        {s.title}
                      </h3>
                      <p className="[font-family:'DM_Sans',Helvetica] text-[#000] text-[14px] leading-relaxed">
                        {s.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* ---------- ANIMATION STYLES ---------- */}
        <style>{`
          @keyframes scroll-rtl {
            0%   { transform: translateX(0%); }
            100% { transform: translateX(-50%); }
          }
          .steps-track {
            animation: scroll-rtl 24s linear infinite;
          }
          .steps-track:hover { animation-play-state: paused; }
          @media (prefers-reduced-motion: reduce) {
            .steps-track { animation: none; transform: translateX(0); }
          }
            .mb-14{
            marging-bottom: 40px;}
        `}</style>
    </section>

    
  );

};
