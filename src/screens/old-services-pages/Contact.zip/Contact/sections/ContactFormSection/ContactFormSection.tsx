import React from "react";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import { Input } from "../../../../components/ui/input";
import { Label } from "../../../../components/ui/label";
import { Textarea } from "../../../../components/ui/textarea";

export const ContactFormSection = (): JSX.Element => {
  const formFields = [
    {
      id: "company",
      label: "Company Name",
      placeholder: "Company Name",
      type: "input",
    },
    { id: "name", label: "Your Name", placeholder: "Your Name", type: "input" },
    {
      id: "email",
      label: "Email Address",
      placeholder: "Email Address",
      type: "input",
    },
    {
      id: "mobile",
      label: "Mobile Number",
      placeholder: "Mobile Number",
      type: "input",
    },
    {
      id: "message",
      label: "Message",
      placeholder: "Message",
      type: "textarea",
    },
  ];

  const contactInfo = [
    {
      icon: "/call.png",
      text: "+91-9769285224",
    },
    {
      icon: "/sms.png",
      text: "collabs@theimpulsedigital.com",
    },
    {
      icon: "/location.png",
      text: "304 - 305,Chirag Infotech, Road No. 16/Z, Ambica Nagar, Wagle Industrial Estate, \nThane, Mumbai 400604",
    },
  ];

  return (
    <section className="w-full bg-[#030019] py-16 lg:py-24" data-section="contact-form">
      <div className="max-w-[1280px] mx-auto px-4 lg:px-8">
        <div className="flex flex-col lg:flex-row items-start gap-12 lg:gap-16">
          <div className="flex flex-col flex-1 items-start gap-12">
            <div className="[font-family:'DM_Sans',Helvetica] font-normal text-[24px] lg:text-[34px] tracking-[0] leading-[28px] lg:leading-[34px]">
              <span className="text-[#ffffffb2] font-medium leading-[40px] lg:leading-[60px]">
                Let&#39;s put
                <br />
              </span>
              <span className="font-bold text-white text-[32px] lg:text-[52px] leading-[36px] lg:leading-[60px]">
                Your Auto-fill to Use!
              </span>
            </div>

            <div className="flex flex-col items-start gap-12 w-full">
              {contactInfo.map((contact, index) => (
                <div
                  key={index}
                  className="flex flex-col items-start gap-4 w-full"
                >
                  <div className="inline-flex items-center gap-2.5 p-2.5 bg-[#ffffff1a] rounded-full">
                    <img
                      className="w-6 h-6"
                      alt="Contact icon"
                      src={contact.icon}
                    />
                  </div>

                  <div className="opacity-90 [font-family:'DM_Sans',Helvetica] font-medium text-white text-lg lg:text-[26px] tracking-[0] leading-7 lg:leading-10">
                    {contact.text.split("\n").map((line, lineIndex) => (
                      <React.Fragment key={lineIndex}>
                        {line}
                        {lineIndex < contact.text.split("\n").length - 1 && (
                          <br />
                        )}
                      </React.Fragment>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Card className="w-full lg:w-[589px] bg-white rounded-[30px] border-0 shadow-none">
            <CardContent className="flex flex-col items-start gap-[30px] p-[30px]">
              <div className="flex flex-col items-start gap-5 w-full">
                {formFields.map((field) => (
                  <div
                    key={field.id}
                    className="flex flex-col items-start gap-3 w-full"
                  >
                    <Label
                      htmlFor={field.id}
                      className="[font-family:'DM_Sans',Helvetica] font-normal text-[#030019] text-sm tracking-[0] leading-[22px]"
                    >
                      {field.label}
                    </Label>

                    {field.type === "input" ? (
                      <Input
                        id={field.id}
                        placeholder={field.placeholder}
                        className="flex h-[50px] items-center gap-2.5 px-4 py-5 w-full bg-[#0300190d] rounded-lg border border-solid border-[#03001908] placeholder:opacity-20 placeholder:[font-family:'DM_Sans',Helvetica] placeholder:font-normal placeholder:text-[#030019] placeholder:text-sm placeholder:tracking-[0] placeholder:leading-[22px]"
                      />
                    ) : (
                      <Textarea
                        id={field.id}
                        placeholder={field.placeholder}
                        className="flex h-[139px] items-start gap-2.5 px-4 py-5 w-full bg-[#0300190d] rounded-lg border border-solid border-[#03001908] placeholder:opacity-20 placeholder:[font-family:'DM_Sans',Helvetica] placeholder:font-normal placeholder:text-[#030019] placeholder:text-sm placeholder:tracking-[0] placeholder:leading-[22px] resize-none"
                      />
                    )}
                  </div>
                ))}
              </div>

              <Button className="inline-flex h-[50px] items-center justify-center gap-2.5 p-5 bg-[#543d98] rounded-xl hover:bg-[#543d98]/90 h-auto">
                <span className="[font-family:'DM_Sans',Helvetica] font-bold text-white text-base tracking-[0] leading-[normal] whitespace-nowrap">
                  Submit
                </span>
                <img
                  className="w-[18px] h-[18px]"
                  alt="Vector"
                  src="/vector-1-3.svg"
                />
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};